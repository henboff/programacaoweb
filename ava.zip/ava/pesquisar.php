<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<section>
  
  <article>
    <h2>Pesquisar livros cadastrados</h2>
    <form method="POST" action="buscar.php">
        Pesquisar:<input type="text" name="pesquisar" placeholder="PESQUISAR">
        <input type="submit" value="PESQUISAR">
    </form>
  </article>
</section>

</body>
</html>
