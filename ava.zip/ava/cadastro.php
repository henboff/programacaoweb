<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>IFRO</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <h1>Cadastro de alunos</h1>
    <form action="cadastrar.php" method="post">
        Nome: <input type="text" name="nome">
        <br><br>
        Quantidade: <input type="number" name="quantidade">
        <br><br>
        Valor: <input type="text" name="valor">
        <br><br>
        <input type="submit" value="CADASTRAR">
    </form>
</body>
</html>